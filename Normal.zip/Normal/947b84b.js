(this.webpackJsonp = this.webpackJsonp || []).push([[1], { //
    1034: function(a, i, t) {
        var e = t(1058);
        e.__esModule && (e = e.default),
        "string" == typeof e && (e = [[a.i, e, ""]]),
        e.locals && (a.exports = e.locals);
        (0,
        t(110).default)("6cb3dd0e", e, !1, {
            sourceMap: !1
        })
    },
    1057: function(a, i, t) {
        "use strict";
        t(1034)
    },
    1058: function(a, i, t) {
        var e = t(109)(!1);
        e.push([a.i, '.u-ta-left{text-align:left!important}.u-ta-right{text-align:right!important}.u-ta-center{text-align:center!important}.u-pointer-events-none{pointer-events:none!important}.effectWindow{width:100%;height:720px;position:absolute;top:0;left:0}.effectWindow .cardnokamisama{width:100%;height:100%;background-color:hsla(0,0%,100%,.8)}.effectWindow .cardnokamisama .item{position:absolute;width:598px;height:339px;top:102px;left:335px;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/cardnokamisama.png)}.effectWindow .cardnokamisama .item:before{content:"";position:absolute;top:calc(50% - 20px);left:calc(50% - 20px);width:20px;height:40px;border-radius:100%;background-color:#fff;box-shadow:0 0 60px 30px #fff,0 0 100px 60px #fff900,0 0 140px 90px #ef0;-webkit-animation:cardnokamisamabefore 1.5s ease 0s infinite alternate;animation:cardnokamisamabefore 1.5s ease 0s infinite alternate}.is-excludeUiAnimation .effectWindow .cardnokamisama .item:before{-webkit-animation:none;animation:none}@-webkit-keyframes cardnokamisamabefore{0%{opacity:0}to{opacity:1}}@keyframes cardnokamisamabefore{0%{opacity:0}to{opacity:1}}.effectWindow .cardnokamisama .item>.img{position:relative;width:100%;height:100%;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/cardnokamisama.png)}.effectWindow .cardnokamisama .item.active{-webkit-animation:cardnokamisamaActive 3s linear 0s infinite;animation:cardnokamisamaActive 3s linear 0s infinite}.is-excludeUiAnimation .effectWindow .cardnokamisama .item.active{-webkit-animation:none;animation:none}@-webkit-keyframes cardnokamisamaActive{0%{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}to{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}18%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-30px,30px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}37%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-20px,-10px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}60%{-webkit-animation-timing-function:linear;-webkit-transform:translate(30px,20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}82%{-webkit-animation-timing-function:linear;-webkit-transform:translate(20px,-20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}}@keyframes cardnokamisamaActive{0%{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}to{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}18%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-30px,30px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}37%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-20px,-10px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}60%{-webkit-animation-timing-function:linear;-webkit-transform:translate(30px,20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}82%{-webkit-animation-timing-function:linear;-webkit-transform:translate(20px,-20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}}.effectWindow .cardnokamisama .frame01{position:absolute;top:0;left:0;width:100%;height:100%;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/cardnokamisama_frame01.png)}.is-excludeDirectingAnimation .effectWindow .cardnokamisama{background-color:hsla(0,0%,100%,.8)!important;-webkit-animation:none;animation:none}.is-excludeDirectingAnimation .effectWindow .cardnokamisama .item{transform:scale(1)!important;-webkit-animation:none;animation:none}.is-excludeDirectingAnimation .effectWindow .cardnokamisama .frame01{opacity:1!important;transform:scale(1)!important;-webkit-animation:none;animation:none}.effectWindow .cardnokamisama.isShow{background-color:hsla(0,0%,100%,0);-webkit-animation:cardnokamisamaIsShow .6s linear 0s 1 normal forwards;animation:cardnokamisamaIsShow .6s linear 0s 1 normal forwards}@-webkit-keyframes cardnokamisamaIsShow{0%{background-color:hsla(0,0%,100%,0)}to{background-color:hsla(0,0%,100%,.8)}}@keyframes cardnokamisamaIsShow{0%{background-color:hsla(0,0%,100%,0)}to{background-color:hsla(0,0%,100%,.8)}}.effectWindow .cardnokamisama.isShow .item{transform:scale(0);-webkit-animation:cardnokamisamaIsShowItem .5s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards;animation:cardnokamisamaIsShowItem .5s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards}@-webkit-keyframes cardnokamisamaIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}@keyframes cardnokamisamaIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}.effectWindow .cardnokamisama.isShow .frame01{opacity:0;-webkit-animation:cardnokamisamaIsShowframe01 .5s cubic-bezier(.33,1,.68,1) .1s 1 normal forwards;animation:cardnokamisamaIsShowframe01 .5s cubic-bezier(.33,1,.68,1) .1s 1 normal forwards}@-webkit-keyframes cardnokamisamaIsShowframe01{0%{opacity:0;transform:scale(1.8)}to{opacity:1;transform:scale(1)}}@keyframes cardnokamisamaIsShowframe01{0%{opacity:0;transform:scale(1.8)}to{opacity:1;transform:scale(1)}}.effectWindow .cardnokamisama.isHidden{-webkit-animation:cardnokamisamaIsHidden .6s linear 0s 1 normal forwards;animation:cardnokamisamaIsHidden .6s linear 0s 1 normal forwards}@-webkit-keyframes cardnokamisamaIsHidden{0%{background-color:hsla(0,0%,100%,.8)}to{background-color:hsla(0,0%,100%,0)}}@keyframes cardnokamisamaIsHidden{0%{background-color:hsla(0,0%,100%,.8)}to{background-color:hsla(0,0%,100%,0)}}.effectWindow .cardnokamisama.isHidden .item{-webkit-animation:cardnokamisamaIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards;animation:cardnokamisamaIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards}@-webkit-keyframes cardnokamisamaIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}@keyframes cardnokamisamaIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}.effectWindow .cardnokamisama.isHidden .item:before{transform-origin:center center;-webkit-animation:cardnokamisamaIsHiddenItemBefore .2s linear 0s 1 normal forwards;animation:cardnokamisamaIsHiddenItemBefore .2s linear 0s 1 normal forwards}@-webkit-keyframes cardnokamisamaIsHiddenItemBefore{0%{transform:scale(1)}to{transform:scale(1.3)}}@keyframes cardnokamisamaIsHiddenItemBefore{0%{transform:scale(1)}to{transform:scale(1.3)}}.effectWindow .cardnokamisama.isHidden .frame01{-webkit-animation:cardnokamisamaIsHiddenframe01 .5s linear 0s 1 normal forwards;animation:cardnokamisamaIsHiddenframe01 .5s linear 0s 1 normal forwards}@-webkit-keyframes cardnokamisamaIsHiddenframe01{0%{opacity:1}to{opacity:0}}@keyframes cardnokamisamaIsHiddenframe01{0%{opacity:1}to{opacity:0}}.effectWindow .kinensennin{width:100%;height:100%;background-color:hsla(0,0%,100%,.8)}.effectWindow .kinensennin .item{position:absolute;width:220px;height:322px;top:102px;left:527px;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/kinensennin.png)}.effectWindow .kinensennin .item:before{content:"";position:absolute;top:calc(50% - 20px);left:calc(50% - 20px);width:20px;height:40px;border-radius:100%;background-color:#fff;box-shadow:0 0 60px 30px #fff,0 0 100px 60px #fff900,0 0 140px 90px #ef0;-webkit-animation:kinensenninbefore 1.5s ease 0s infinite alternate;animation:kinensenninbefore 1.5s ease 0s infinite alternate}.is-excludeUiAnimation .effectWindow .kinensennin .item:before{-webkit-animation:none;animation:none}@-webkit-keyframes kinensenninbefore{0%{opacity:0}to{opacity:1}}@keyframes kinensenninbefore{0%{opacity:0}to{opacity:1}}.effectWindow .kinensennin .item>.img{position:relative;width:100%;height:100%;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/kinensennin.png)}.effectWindow .kinensennin .item.active{-webkit-animation:kinensenninActive 3s linear 0s infinite;animation:kinensenninActive 3s linear 0s infinite}.is-excludeUiAnimation .effectWindow .kinensennin .item.active{-webkit-animation:none;animation:none}@-webkit-keyframes kinensenninActive{0%{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}to{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}18%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-30px,30px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}37%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-20px,-10px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}60%{-webkit-animation-timing-function:linear;-webkit-transform:translate(30px,20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}82%{-webkit-animation-timing-function:linear;-webkit-transform:translate(20px,-20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}}@keyframes kinensenninActive{0%{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}to{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}18%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-30px,30px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}37%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-20px,-10px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}60%{-webkit-animation-timing-function:linear;-webkit-transform:translate(30px,20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}82%{-webkit-animation-timing-function:linear;-webkit-transform:translate(20px,-20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}}.is-excludeDirectingAnimation .effectWindow .kinensennin .item{background-color:hsla(0,0%,100%,.8)!important}.effectWindow .kinensennin .frame01{position:absolute;top:0;left:0;width:100%;height:100%;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/kinensennin_frame01.png)}.is-excludeDirectingAnimation .effectWindow .kinensennin{background-color:hsla(0,0%,100%,.8)!important;-webkit-animation:none;animation:none}.is-excludeDirectingAnimation .effectWindow .kinensennin .frame01,.is-excludeDirectingAnimation .effectWindow .kinensennin .item{transform:scale(1)!important;-webkit-animation:none;animation:none}.is-excludeDirectingAnimation .effectWindow .kinensennin .frame01{opacity:1!important}.effectWindow .kinensennin.isShow{background-color:hsla(0,0%,100%,0);-webkit-animation:kinensenninIsShow .6s linear 0s 1 normal forwards;animation:kinensenninIsShow .6s linear 0s 1 normal forwards}@-webkit-keyframes kinensenninIsShow{0%{background-color:hsla(0,0%,100%,0)}to{background-color:hsla(0,0%,100%,.8)}}@keyframes kinensenninIsShow{0%{background-color:hsla(0,0%,100%,0)}to{background-color:hsla(0,0%,100%,.8)}}.effectWindow .kinensennin.isShow .item{transform:scale(0);-webkit-animation:kinensenninIsShowItem .5s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards;animation:kinensenninIsShowItem .5s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards}@-webkit-keyframes kinensenninIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}@keyframes kinensenninIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}.effectWindow .kinensennin.isShow .frame01{opacity:0;-webkit-animation:kinensenninIsShowframe01 .5s cubic-bezier(.33,1,.68,1) .1s 1 normal forwards;animation:kinensenninIsShowframe01 .5s cubic-bezier(.33,1,.68,1) .1s 1 normal forwards}@-webkit-keyframes kinensenninIsShowframe01{0%{opacity:0;transform:scale(1.8)}to{opacity:1;transform:scale(1)}}@keyframes kinensenninIsShowframe01{0%{opacity:0;transform:scale(1.8)}to{opacity:1;transform:scale(1)}}.effectWindow .kinensennin.isHidden{-webkit-animation:kinensenninIsHidden .6s linear 0s 1 normal forwards;animation:kinensenninIsHidden .6s linear 0s 1 normal forwards}@-webkit-keyframes kinensenninIsHidden{0%{background-color:hsla(0,0%,100%,.8)}to{background-color:hsla(0,0%,100%,0)}}@keyframes kinensenninIsHidden{0%{background-color:hsla(0,0%,100%,.8)}to{background-color:hsla(0,0%,100%,0)}}.effectWindow .kinensennin.isHidden .item{-webkit-animation:kinensenninIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards;animation:kinensenninIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards}@-webkit-keyframes kinensenninIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}@keyframes kinensenninIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}.effectWindow .kinensennin.isHidden .item:before{transform-origin:center center;-webkit-animation:kinensenninIsHiddenItemBefore .2s linear 0s 1 normal forwards;animation:kinensenninIsHiddenItemBefore .2s linear 0s 1 normal forwards}@-webkit-keyframes kinensenninIsHiddenItemBefore{0%{transform:scale(1)}to{transform:scale(1.3)}}@keyframes kinensenninIsHiddenItemBefore{0%{transform:scale(1)}to{transform:scale(1.3)}}.effectWindow .kinensennin.isHidden .frame01{-webkit-animation:kinensenninIsHiddenframe01 .5s linear 0s 1 normal forwards;animation:kinensenninIsHiddenframe01 .5s linear 0s 1 normal forwards}@-webkit-keyframes kinensenninIsHiddenframe01{0%{opacity:1}to{opacity:0}}@keyframes kinensenninIsHiddenframe01{0%{opacity:1}to{opacity:0}}.effectWindow .toranitsubasa{width:100%;height:100%;background-color:rgba(0,0,0,.4)}.effectWindow .toranitsubasa .item{position:absolute;width:100%;height:100%}.is-excludeDirectingAnimation .effectWindow .toranitsubasa .item .star,.is-excludeDirectingAnimation .effectWindow .toranitsubasa .item .tiger,.is-excludeDirectingAnimation .effectWindow .toranitsubasa .item .tigers{-webkit-animation:none!important;animation:none!important}.effectWindow .toranitsubasa .item .tigers{position:absolute;-webkit-animation:toranitsubasaRotate 4s linear infinite;animation:toranitsubasaRotate 4s linear infinite;left:0;right:0;top:100px;margin:auto;transform-origin:center center;width:500px;height:500px}.effectWindow .toranitsubasa .item .tiger{position:absolute;width:297px;height:297px;top:-30px;left:50px;animation:toranitsubasaRotate 4s linear infinite reverse;transform-origin:center center}.effectWindow .toranitsubasa .item .tiger .star{position:absolute;width:26px;height:25px;transform-origin:center center;-webkit-animation:toranitsubasaStar .6s linear infinite;animation:toranitsubasaStar .6s linear infinite}.effectWindow .toranitsubasa .item .tiger .star1{position:absolute;top:60px;left:60px;-webkit-animation-delay:.1s;animation-delay:.1s}.effectWindow .toranitsubasa .item .tiger .star2{position:absolute;top:80px;left:230px;-webkit-animation-delay:.4s;animation-delay:.4s}.effectWindow .toranitsubasa .item .tiger .star3{position:absolute;top:180px;left:40px;-webkit-animation-delay:.7s;animation-delay:.7s}.effectWindow .toranitsubasa .item .tiger .star4{position:absolute;top:240px;left:170px;-webkit-animation-delay:1s;animation-delay:1s}.effectWindow .toranitsubasa .item .tiger1{top:-130px;left:260px}.effectWindow .toranitsubasa .item .tiger2{top:140px;left:375px}.effectWindow .toranitsubasa .item .tiger3{top:380px;left:100px}.effectWindow .toranitsubasa .item .tiger4{top:140px;left:-175px}.effectWindow .toranitsubasa .item .tiger5{top:-130px;left:-60px}@-webkit-keyframes toranitsubasaRotate{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@keyframes toranitsubasaRotate{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@-webkit-keyframes toranitsubasaStar{0%{opacity:0;transform:scale(3) rotate(0deg)}to{opacity:1;transform:scale(0) rotate(180deg)}}@keyframes toranitsubasaStar{0%{opacity:0;transform:scale(3) rotate(0deg)}to{opacity:1;transform:scale(0) rotate(180deg)}}.effectWindow .toranitsubasa .frame01{display:none}.effectWindow .toranitsubasa.isShow{background-color:transparent;-webkit-animation:toranitsubasaIsShow .6s linear 0s 1 normal forwards;animation:toranitsubasaIsShow .6s linear 0s 1 normal forwards}@-webkit-keyframes toranitsubasaIsShow{0%{background-color:transparent}to{background-color:rgba(0,0,0,.4)}}@keyframes toranitsubasaIsShow{0%{background-color:transparent}to{background-color:rgba(0,0,0,.4)}}.effectWindow .toranitsubasa.isShow .item{transform:scale(0);-webkit-animation:toranitsubasaIsShowItem .6s cubic-bezier(.19,1,.22,1) 0s 1 normal forwards;animation:toranitsubasaIsShowItem .6s cubic-bezier(.19,1,.22,1) 0s 1 normal forwards}@-webkit-keyframes toranitsubasaIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}@keyframes toranitsubasaIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}.effectWindow .toranitsubasa.isHidden{-webkit-animation:toranitsubasaIsHidden .6s linear 0s 1 normal forwards;animation:toranitsubasaIsHidden .6s linear 0s 1 normal forwards}@-webkit-keyframes toranitsubasaIsHidden{0%{background-color:rgba(0,0,0,.4)}to{background-color:transparent}}@keyframes toranitsubasaIsHidden{0%{background-color:rgba(0,0,0,.4)}to{background-color:transparent}}.effectWindow .toranitsubasa.isHidden .item{-webkit-animation:toranitsubasaIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards;animation:toranitsubasaIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards}@-webkit-keyframes toranitsubasaIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}@keyframes toranitsubasaIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}.effectWindow .saikai{width:100%;height:100%;background-color:rgba(0,0,0,.4)}.effectWindow .saikai .item{position:absolute;width:100%;height:100%}.effectWindow .saikai .item .megami{position:absolute;left:0;right:0;top:20px;margin:auto;width:495px;height:612px;transform-origin:center center}.effectWindow .saikai .item .lights{position:absolute;width:1280px;height:720px;transform-origin:center center;mix-blend-mode:screen}.effectWindow .saikai .item .lights img{-webkit-animation:saikaiLightsImage 1s ease-in-out infinite alternate;animation:saikaiLightsImage 1s ease-in-out infinite alternate}.is-excludeDirectingAnimation .effectWindow .saikai .item .lights img{-webkit-animation:none;animation:none;opacity:1}@-webkit-keyframes saikaiLightsImage{0%{opacity:.7}to{opacity:1}}@keyframes saikaiLightsImage{0%{opacity:.7}to{opacity:1}}.effectWindow .saikai .item .stars{position:absolute;width:100%;height:100%}.effectWindow .saikai .item .stars .star{position:absolute;width:26px;height:25px;transform-origin:center center}.is-excludeDirectingAnimation .effectWindow .saikai .item .stars .star{-webkit-animation:none!important;animation:none!important;opacity:0!important}.is-excludeDirectingAnimation .effectWindow .saikai .item .stars .star img{-webkit-animation:none!important;animation:none!important;opacity:1!important}.effectWindow .saikai .item .stars .star:first-child{-webkit-animation:saikaiStar1 3s linear infinite;animation:saikaiStar1 3s linear infinite;-webkit-animation-delay:3s;animation-delay:3s;transform-origin:center center;transform:scale(1.3) rotate(148deg);opacity:0}.effectWindow .saikai .item .stars .star:first-child img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar1{0%{opacity:1;top:-20px;left:599px}90%{opacity:1}to{opacity:0;top:471px;left:656px}}@keyframes saikaiStar1{0%{opacity:1;top:-20px;left:599px}90%{opacity:1}to{opacity:0;top:471px;left:656px}}@-webkit-keyframes saikaiStarImg1{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg1{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(2){-webkit-animation:saikaiStar2 3s linear infinite;animation:saikaiStar2 3s linear infinite;-webkit-animation-delay:2s;animation-delay:2s;transform-origin:center center;transform:scale(.7) rotate(303deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(2) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar2{0%{opacity:1;top:-20px;left:591px}90%{opacity:1}to{opacity:0;top:396px;left:551px}}@keyframes saikaiStar2{0%{opacity:1;top:-20px;left:591px}90%{opacity:1}to{opacity:0;top:396px;left:551px}}@-webkit-keyframes saikaiStarImg2{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg2{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(3){-webkit-animation:saikaiStar3 4s linear infinite;animation:saikaiStar3 4s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(1.1) rotate(183deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(3) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar3{0%{opacity:1;top:-20px;left:609px}90%{opacity:1}to{opacity:0;top:449px;left:665px}}@keyframes saikaiStar3{0%{opacity:1;top:-20px;left:609px}90%{opacity:1}to{opacity:0;top:449px;left:665px}}@-webkit-keyframes saikaiStarImg3{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg3{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(4){-webkit-animation:saikaiStar4 4s linear infinite;animation:saikaiStar4 4s linear infinite;-webkit-animation-delay:2s;animation-delay:2s;transform-origin:center center;transform:scale(1.4) rotate(112deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(4) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:1s;animation-delay:1s;opacity:0}@-webkit-keyframes saikaiStar4{0%{opacity:1;top:-20px;left:641px}90%{opacity:1}to{opacity:0;top:354px;left:516px}}@keyframes saikaiStar4{0%{opacity:1;top:-20px;left:641px}90%{opacity:1}to{opacity:0;top:354px;left:516px}}@-webkit-keyframes saikaiStarImg4{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg4{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(5){-webkit-animation:saikaiStar5 3s linear infinite;animation:saikaiStar5 3s linear infinite;-webkit-animation-delay:3s;animation-delay:3s;transform-origin:center center;transform:scale(.7) rotate(258deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(5) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:1s;animation-delay:1s;opacity:0}@-webkit-keyframes saikaiStar5{0%{opacity:1;top:-20px;left:601px}90%{opacity:1}to{opacity:0;top:438px;left:709px}}@keyframes saikaiStar5{0%{opacity:1;top:-20px;left:601px}90%{opacity:1}to{opacity:0;top:438px;left:709px}}@-webkit-keyframes saikaiStarImg5{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg5{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(6){-webkit-animation:saikaiStar6 3s linear infinite;animation:saikaiStar6 3s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(.6) rotate(343deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(6) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar6{0%{opacity:1;top:-20px;left:630px}90%{opacity:1}to{opacity:0;top:427px;left:572px}}@keyframes saikaiStar6{0%{opacity:1;top:-20px;left:630px}90%{opacity:1}to{opacity:0;top:427px;left:572px}}@-webkit-keyframes saikaiStarImg6{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg6{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(7){-webkit-animation:saikaiStar7 3s linear infinite;animation:saikaiStar7 3s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(1.1) rotate(156deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(7) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:1s;animation-delay:1s;opacity:0}@-webkit-keyframes saikaiStar7{0%{opacity:1;top:-20px;left:655px}90%{opacity:1}to{opacity:0;top:446px;left:765px}}@keyframes saikaiStar7{0%{opacity:1;top:-20px;left:655px}90%{opacity:1}to{opacity:0;top:446px;left:765px}}@-webkit-keyframes saikaiStarImg7{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg7{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(8){-webkit-animation:saikaiStar8 3s linear infinite;animation:saikaiStar8 3s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(1.1) rotate(193deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(8) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar8{0%{opacity:1;top:-20px;left:592px}90%{opacity:1}to{opacity:0;top:490px;left:664px}}@keyframes saikaiStar8{0%{opacity:1;top:-20px;left:592px}90%{opacity:1}to{opacity:0;top:490px;left:664px}}@-webkit-keyframes saikaiStarImg8{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg8{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(9){-webkit-animation:saikaiStar9 3s linear infinite;animation:saikaiStar9 3s linear infinite;-webkit-animation-delay:3s;animation-delay:3s;transform-origin:center center;transform:scale(1.3) rotate(185deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(9) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:1s;animation-delay:1s;opacity:0}@-webkit-keyframes saikaiStar9{0%{opacity:1;top:-20px;left:640px}90%{opacity:1}to{opacity:0;top:313px;left:610px}}@keyframes saikaiStar9{0%{opacity:1;top:-20px;left:640px}90%{opacity:1}to{opacity:0;top:313px;left:610px}}@-webkit-keyframes saikaiStarImg9{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg9{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(10){-webkit-animation:saikaiStar10 3s linear infinite;animation:saikaiStar10 3s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(.6) rotate(309deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(10) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar10{0%{opacity:1;top:-20px;left:617px}90%{opacity:1}to{opacity:0;top:348px;left:471px}}@keyframes saikaiStar10{0%{opacity:1;top:-20px;left:617px}90%{opacity:1}to{opacity:0;top:348px;left:471px}}@-webkit-keyframes saikaiStarImg10{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg10{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(11){-webkit-animation:saikaiStar11 4s linear infinite;animation:saikaiStar11 4s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(1) rotate(231deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(11) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar11{0%{opacity:1;top:-20px;left:605px}90%{opacity:1}to{opacity:0;top:352px;left:533px}}@keyframes saikaiStar11{0%{opacity:1;top:-20px;left:605px}90%{opacity:1}to{opacity:0;top:352px;left:533px}}@-webkit-keyframes saikaiStarImg11{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg11{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(12){-webkit-animation:saikaiStar12 3s linear infinite;animation:saikaiStar12 3s linear infinite;-webkit-animation-delay:3s;animation-delay:3s;transform-origin:center center;transform:scale(1.4) rotate(199deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(12) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar12{0%{opacity:1;top:-20px;left:649px}90%{opacity:1}to{opacity:0;top:349px;left:743px}}@keyframes saikaiStar12{0%{opacity:1;top:-20px;left:649px}90%{opacity:1}to{opacity:0;top:349px;left:743px}}@-webkit-keyframes saikaiStarImg12{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg12{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(13){-webkit-animation:saikaiStar13 4s linear infinite;animation:saikaiStar13 4s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(1.2) rotate(172deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(13) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar13{0%{opacity:1;top:-20px;left:606px}90%{opacity:1}to{opacity:0;top:441px;left:691px}}@keyframes saikaiStar13{0%{opacity:1;top:-20px;left:606px}90%{opacity:1}to{opacity:0;top:441px;left:691px}}@-webkit-keyframes saikaiStarImg13{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg13{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(14){-webkit-animation:saikaiStar14 3s linear infinite;animation:saikaiStar14 3s linear infinite;-webkit-animation-delay:2s;animation-delay:2s;transform-origin:center center;transform:scale(1) rotate(114deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(14) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:1s;animation-delay:1s;opacity:0}@-webkit-keyframes saikaiStar14{0%{opacity:1;top:-20px;left:598px}90%{opacity:1}to{opacity:0;top:304px;left:400px}}@keyframes saikaiStar14{0%{opacity:1;top:-20px;left:598px}90%{opacity:1}to{opacity:0;top:304px;left:400px}}@-webkit-keyframes saikaiStarImg14{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg14{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(15){-webkit-animation:saikaiStar15 3s linear infinite;animation:saikaiStar15 3s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(.7) rotate(318deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(15) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar15{0%{opacity:1;top:-20px;left:654px}90%{opacity:1}to{opacity:0;top:478px;left:776px}}@keyframes saikaiStar15{0%{opacity:1;top:-20px;left:654px}90%{opacity:1}to{opacity:0;top:478px;left:776px}}@-webkit-keyframes saikaiStarImg15{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg15{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(16){-webkit-animation:saikaiStar16 4s linear infinite;animation:saikaiStar16 4s linear infinite;-webkit-animation-delay:3s;animation-delay:3s;transform-origin:center center;transform:scale(.7) rotate(343deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(16) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar16{0%{opacity:1;top:-20px;left:619px}90%{opacity:1}to{opacity:0;top:448px;left:684px}}@keyframes saikaiStar16{0%{opacity:1;top:-20px;left:619px}90%{opacity:1}to{opacity:0;top:448px;left:684px}}@-webkit-keyframes saikaiStarImg16{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg16{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(17){-webkit-animation:saikaiStar17 3s linear infinite;animation:saikaiStar17 3s linear infinite;-webkit-animation-delay:2s;animation-delay:2s;transform-origin:center center;transform:scale(.7) rotate(60deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(17) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar17{0%{opacity:1;top:-20px;left:594px}90%{opacity:1}to{opacity:0;top:472px;left:528px}}@keyframes saikaiStar17{0%{opacity:1;top:-20px;left:594px}90%{opacity:1}to{opacity:0;top:472px;left:528px}}@-webkit-keyframes saikaiStarImg17{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg17{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(18){-webkit-animation:saikaiStar18 4s linear infinite;animation:saikaiStar18 4s linear infinite;-webkit-animation-delay:3s;animation-delay:3s;transform-origin:center center;transform:scale(1.5) rotate(181deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(18) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:1s;animation-delay:1s;opacity:0}@-webkit-keyframes saikaiStar18{0%{opacity:1;top:-20px;left:640px}90%{opacity:1}to{opacity:0;top:399px;left:591px}}@keyframes saikaiStar18{0%{opacity:1;top:-20px;left:640px}90%{opacity:1}to{opacity:0;top:399px;left:591px}}@-webkit-keyframes saikaiStarImg18{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg18{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(19){-webkit-animation:saikaiStar19 3s linear infinite;animation:saikaiStar19 3s linear infinite;-webkit-animation-delay:3s;animation-delay:3s;transform-origin:center center;transform:scale(1.1) rotate(143deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(19) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar19{0%{opacity:1;top:-20px;left:655px}90%{opacity:1}to{opacity:0;top:447px;left:621px}}@keyframes saikaiStar19{0%{opacity:1;top:-20px;left:655px}90%{opacity:1}to{opacity:0;top:447px;left:621px}}@-webkit-keyframes saikaiStarImg19{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg19{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(20){-webkit-animation:saikaiStar20 3s linear infinite;animation:saikaiStar20 3s linear infinite;-webkit-animation-delay:2s;animation-delay:2s;transform-origin:center center;transform:scale(.8) rotate(346deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(20) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar20{0%{opacity:1;top:-20px;left:622px}90%{opacity:1}to{opacity:0;top:474px;left:785px}}@keyframes saikaiStar20{0%{opacity:1;top:-20px;left:622px}90%{opacity:1}to{opacity:0;top:474px;left:785px}}@-webkit-keyframes saikaiStarImg20{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg20{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(21){-webkit-animation:saikaiStar21 3s linear infinite;animation:saikaiStar21 3s linear infinite;-webkit-animation-delay:2s;animation-delay:2s;transform-origin:center center;transform:scale(1.3) rotate(42deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(21) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:1s;animation-delay:1s;opacity:0}@-webkit-keyframes saikaiStar21{0%{opacity:1;top:-20px;left:653px}90%{opacity:1}to{opacity:0;top:333px;left:654px}}@keyframes saikaiStar21{0%{opacity:1;top:-20px;left:653px}90%{opacity:1}to{opacity:0;top:333px;left:654px}}@-webkit-keyframes saikaiStarImg21{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg21{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(22){-webkit-animation:saikaiStar22 3s linear infinite;animation:saikaiStar22 3s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(1.5) rotate(85deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(22) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:1s;animation-delay:1s;opacity:0}@-webkit-keyframes saikaiStar22{0%{opacity:1;top:-20px;left:657px}90%{opacity:1}to{opacity:0;top:405px;left:522px}}@keyframes saikaiStar22{0%{opacity:1;top:-20px;left:657px}90%{opacity:1}to{opacity:0;top:405px;left:522px}}@-webkit-keyframes saikaiStarImg22{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg22{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(23){-webkit-animation:saikaiStar23 4s linear infinite;animation:saikaiStar23 4s linear infinite;-webkit-animation-delay:2s;animation-delay:2s;transform-origin:center center;transform:scale(.8) rotate(356deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(23) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar23{0%{opacity:1;top:-20px;left:651px}90%{opacity:1}to{opacity:0;top:312px;left:849px}}@keyframes saikaiStar23{0%{opacity:1;top:-20px;left:651px}90%{opacity:1}to{opacity:0;top:312px;left:849px}}@-webkit-keyframes saikaiStarImg23{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg23{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(24){-webkit-animation:saikaiStar24 3s linear infinite;animation:saikaiStar24 3s linear infinite;-webkit-animation-delay:3s;animation-delay:3s;transform-origin:center center;transform:scale(1.5) rotate(75deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(24) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:1s;animation-delay:1s;opacity:0}@-webkit-keyframes saikaiStar24{0%{opacity:1;top:-20px;left:633px}90%{opacity:1}to{opacity:0;top:493px;left:543px}}@keyframes saikaiStar24{0%{opacity:1;top:-20px;left:633px}90%{opacity:1}to{opacity:0;top:493px;left:543px}}@-webkit-keyframes saikaiStarImg24{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg24{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(25){-webkit-animation:saikaiStar25 4s linear infinite;animation:saikaiStar25 4s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(.8) rotate(53deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(25) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:1s;animation-delay:1s;opacity:0}@-webkit-keyframes saikaiStar25{0%{opacity:1;top:-20px;left:646px}90%{opacity:1}to{opacity:0;top:481px;left:671px}}@keyframes saikaiStar25{0%{opacity:1;top:-20px;left:646px}90%{opacity:1}to{opacity:0;top:481px;left:671px}}@-webkit-keyframes saikaiStarImg25{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg25{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(26){-webkit-animation:saikaiStar26 3s linear infinite;animation:saikaiStar26 3s linear infinite;-webkit-animation-delay:2s;animation-delay:2s;transform-origin:center center;transform:scale(1.2) rotate(90deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(26) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar26{0%{opacity:1;top:-20px;left:598px}90%{opacity:1}to{opacity:0;top:366px;left:613px}}@keyframes saikaiStar26{0%{opacity:1;top:-20px;left:598px}90%{opacity:1}to{opacity:0;top:366px;left:613px}}@-webkit-keyframes saikaiStarImg26{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg26{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(27){-webkit-animation:saikaiStar27 3s linear infinite;animation:saikaiStar27 3s linear infinite;-webkit-animation-delay:3s;animation-delay:3s;transform-origin:center center;transform:scale(1.3) rotate(284deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(27) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar27{0%{opacity:1;top:-20px;left:605px}90%{opacity:1}to{opacity:0;top:421px;left:784px}}@keyframes saikaiStar27{0%{opacity:1;top:-20px;left:605px}90%{opacity:1}to{opacity:0;top:421px;left:784px}}@-webkit-keyframes saikaiStarImg27{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg27{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(28){-webkit-animation:saikaiStar28 4s linear infinite;animation:saikaiStar28 4s linear infinite;-webkit-animation-delay:1s;animation-delay:1s;transform-origin:center center;transform:scale(1.2) rotate(173deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(28) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar28{0%{opacity:1;top:-20px;left:615px}90%{opacity:1}to{opacity:0;top:374px;left:689px}}@keyframes saikaiStar28{0%{opacity:1;top:-20px;left:615px}90%{opacity:1}to{opacity:0;top:374px;left:689px}}@-webkit-keyframes saikaiStarImg28{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg28{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(29){-webkit-animation:saikaiStar29 4s linear infinite;animation:saikaiStar29 4s linear infinite;-webkit-animation-delay:2s;animation-delay:2s;transform-origin:center center;transform:scale(1.5) rotate(99deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(29) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar29{0%{opacity:1;top:-20px;left:656px}90%{opacity:1}to{opacity:0;top:303px;left:554px}}@keyframes saikaiStar29{0%{opacity:1;top:-20px;left:656px}90%{opacity:1}to{opacity:0;top:303px;left:554px}}@-webkit-keyframes saikaiStarImg29{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg29{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .item .stars .star:nth-child(30){-webkit-animation:saikaiStar30 3s linear infinite;animation:saikaiStar30 3s linear infinite;-webkit-animation-delay:3s;animation-delay:3s;transform-origin:center center;transform:scale(1.1) rotate(145deg);opacity:0}.effectWindow .saikai .item .stars .star:nth-child(30) img{-webkit-animation:saikaiLightsImage .1s ease-in-out infinite alternate;animation:saikaiLightsImage .1s ease-in-out infinite alternate;-webkit-animation-delay:2s;animation-delay:2s;opacity:0}@-webkit-keyframes saikaiStar30{0%{opacity:1;top:-20px;left:658px}90%{opacity:1}to{opacity:0;top:310px;left:502px}}@keyframes saikaiStar30{0%{opacity:1;top:-20px;left:658px}90%{opacity:1}to{opacity:0;top:310px;left:502px}}@-webkit-keyframes saikaiStarImg30{0%{opacity:.2}to{opacity:1}}@keyframes saikaiStarImg30{0%{opacity:.2}to{opacity:1}}.effectWindow .saikai .frame01{display:none}.effectWindow .saikai.isShow{background-color:transparent;-webkit-animation:saikaiIsShow 3.5s linear 0s 1 normal forwards;animation:saikaiIsShow 3.5s linear 0s 1 normal forwards}@-webkit-keyframes saikaiIsShow{0%{background-color:transparent}15%{background-color:rgba(0,0,0,.4)}to{background-color:rgba(0,0,0,.4)}}@keyframes saikaiIsShow{0%{background-color:transparent}15%{background-color:rgba(0,0,0,.4)}to{background-color:rgba(0,0,0,.4)}}.effectWindow .saikai.isShow .item .megami{top:-700px;-webkit-animation:saikaiIsShowMegami 3s cubic-bezier(.34,1.56,.64,1) .5s 1 normal forwards;animation:saikaiIsShowMegami 3s cubic-bezier(.34,1.56,.64,1) .5s 1 normal forwards}.effectWindow .saikai.isShow .item .lights{opacity:0;-webkit-animation:saikaiIsShowLights 2s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards;animation:saikaiIsShowLights 2s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards}@-webkit-keyframes saikaiIsShowMegami{0%{top:-700px}to{top:20px}}@keyframes saikaiIsShowMegami{0%{top:-700px}to{top:20px}}@-webkit-keyframes saikaiIsShowLights{0%{opacity:0}to{opacity:1}}@keyframes saikaiIsShowLights{0%{opacity:0}to{opacity:1}}.effectWindow .saikai.isHidden{-webkit-animation:saikaiIsHidden .6s linear 1.4s 1 normal forwards;animation:saikaiIsHidden .6s linear 1.4s 1 normal forwards}@-webkit-keyframes saikaiIsHidden{0%{background-color:rgba(0,0,0,.4)}to{background-color:transparent}}@keyframes saikaiIsHidden{0%{background-color:rgba(0,0,0,.4)}to{background-color:transparent}}.effectWindow .saikai.isHidden .item .megami{-webkit-animation:saikaiIsHiddenMegami 2s cubic-bezier(.645,.045,.355,1) 0s 1 normal forwards;animation:saikaiIsHiddenMegami 2s cubic-bezier(.645,.045,.355,1) 0s 1 normal forwards}.effectWindow .saikai.isHidden .item .lights{-webkit-animation:saikaIsHiddeniLights 1s cubic-bezier(.645,.045,.355,1) 0s 1 normal forwards;animation:saikaIsHiddeniLights 1s cubic-bezier(.645,.045,.355,1) 0s 1 normal forwards}.effectWindow .saikai.isHidden .item .stars{-webkit-animation:saikaiIsHiddenStars 1s cubic-bezier(.645,.045,.355,1) 0s 1 normal forwards;animation:saikaiIsHiddenStars 1s cubic-bezier(.645,.045,.355,1) 0s 1 normal forwards}@-webkit-keyframes saikaiIsHiddenMegami{0%{top:20px}to{top:-700px}}@keyframes saikaiIsHiddenMegami{0%{top:20px}to{top:-700px}}@-webkit-keyframes saikaiIsHiddenLights{0%{opacity:1}to{opacity:0}}@keyframes saikaiIsHiddenLights{0%{opacity:1}to{opacity:0}}@-webkit-keyframes saikaiIsHiddenStars{0%{opacity:1}to{opacity:0}}@keyframes saikaiIsHiddenStars{0%{opacity:1}to{opacity:0}}.effectWindow .tokkaekko{width:100%;height:100%;background-color:rgba(0,0,0,.4)}.effectWindow .tokkaekko .item{position:absolute;width:100%;height:100%}.is-excludeDirectingAnimation .effectWindow .tokkaekko .item,.is-excludeDirectingAnimation .effectWindow .tokkaekko .item .charas .bg,.is-excludeDirectingAnimation .effectWindow .tokkaekko .item .charas [class^=gitter]{-webkit-animation:none!important;animation:none!important}.effectWindow .tokkaekko .item .charas{position:absolute;transform-origin:center center}.effectWindow .tokkaekko .item .charas .chara{position:relative}.effectWindow .tokkaekko .item .charas .bg{position:absolute;top:50%;left:0;right:0;margin:auto;transform:translateY(-50%);transform-origin:center center}.effectWindow .tokkaekko .item .charas .gitter{position:absolute;top:0;left:0;transform-origin:center center}.effectWindow .tokkaekko .item .chara-r-1{top:70px;right:50px;width:349px;height:221px}.effectWindow .tokkaekko .item .chara-r-1 .bg{-webkit-animation:tokkaekkoBg 5s linear infinite;animation:tokkaekkoBg 5s linear infinite}.effectWindow .tokkaekko .item .chara-r-1 .gitter{width:70px;height:68px;-webkit-animation:tokkaekkoGitter .6s linear infinite;animation:tokkaekkoGitter .6s linear infinite}.effectWindow .tokkaekko .item .chara-r-1 .gitter1{top:30px;left:60px;-webkit-animation-delay:0;animation-delay:0}.effectWindow .tokkaekko .item .chara-r-1 .gitter2{top:0;left:180px;-webkit-animation-delay:.3s;animation-delay:.3s}.effectWindow .tokkaekko .item .chara-r-1 .gitter3{top:180px;left:50px;-webkit-animation-delay:.6s;animation-delay:.6s}.effectWindow .tokkaekko .item .chara-r-1 .gitter4{top:150px;left:260px;-webkit-animation-delay:.9s;animation-delay:.9s}.effectWindow .tokkaekko .item .chara-r-2{top:300px;right:350px;width:244px;height:154px}.effectWindow .tokkaekko .item .chara-r-2 .bg{-webkit-animation:tokkaekkoBg 5s linear infinite;animation:tokkaekkoBg 5s linear infinite}.effectWindow .tokkaekko .item .chara-r-2 .gitter{width:40px;height:38px;-webkit-animation:tokkaekkoGitter .6s linear infinite;animation:tokkaekkoGitter .6s linear infinite;-webkit-animation-delay:.2s;animation-delay:.2s}.effectWindow .tokkaekko .item .chara-r-2 .gitter1{top:30px;left:40px;-webkit-animation-delay:.1s;animation-delay:.1s}.effectWindow .tokkaekko .item .chara-r-2 .gitter2{top:0;left:140px;-webkit-animation-delay:.4s;animation-delay:.4s}.effectWindow .tokkaekko .item .chara-r-2 .gitter3{top:130px;left:50px;-webkit-animation-delay:.7s;animation-delay:.7s}.effectWindow .tokkaekko .item .chara-r-2 .gitter4{top:100px;left:180px;-webkit-animation-delay:1s;animation-delay:1s}.effectWindow .tokkaekko .item .chara-l-1{top:70px;left:50px;width:413px;height:224px}.effectWindow .tokkaekko .item .chara-l-1 .bg{-webkit-animation:tokkaekkoBg2 1s linear infinite alternate;animation:tokkaekkoBg2 1s linear infinite alternate}.effectWindow .tokkaekko .item .chara-l-1 .gitter{width:45px;height:42px;-webkit-animation:tokkaekkoGitter2 .6s linear infinite;animation:tokkaekkoGitter2 .6s linear infinite}.effectWindow .tokkaekko .item .chara-l-1 .gitter1{top:25px;left:95px;-webkit-animation-delay:.2s;animation-delay:.2s}.effectWindow .tokkaekko .item .chara-l-1 .gitter2{top:50px;left:280px;-webkit-animation-delay:.4s;animation-delay:.4s}.effectWindow .tokkaekko .item .chara-l-2{top:300px;left:350px;width:289px;height:156px}.effectWindow .tokkaekko .item .chara-l-2 .bg{-webkit-animation:tokkaekkoBg2 1s linear infinite alternate;animation:tokkaekkoBg2 1s linear infinite alternate;-webkit-animation-delay:.3s;animation-delay:.3s}.effectWindow .tokkaekko .item .chara-l-2 .gitter{width:30px;height:28px;-webkit-animation:tokkaekkoGitter2 .6s linear infinite;animation:tokkaekkoGitter2 .6s linear infinite}.effectWindow .tokkaekko .item .chara-l-2 .gitter1{top:20px;left:70px;-webkit-animation-delay:.1s;animation-delay:.1s}.effectWindow .tokkaekko .item .chara-l-2 .gitter2{top:40px;left:200px;-webkit-animation-delay:.3s;animation-delay:.3s}@-webkit-keyframes tokkaekkoGitter{0%{opacity:0;transform:scale(3) rotate(0deg)}to{opacity:1;transform:scale(0) rotate(180deg)}}@keyframes tokkaekkoGitter{0%{opacity:0;transform:scale(3) rotate(0deg)}to{opacity:1;transform:scale(0) rotate(180deg)}}@-webkit-keyframes tokkaekkoGitter2{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@keyframes tokkaekkoGitter2{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}@-webkit-keyframes tokkaekkoBg{0%{transform:translateY(-50%) rotate(0deg)}to{transform:translateY(-50%) rotate(1turn)}}@keyframes tokkaekkoBg{0%{transform:translateY(-50%) rotate(0deg)}to{transform:translateY(-50%) rotate(1turn)}}@-webkit-keyframes tokkaekkoBg2{0%{opacity:.8;transform:translateY(-50%) scale(1)}to{opacity:1;transform:translateY(-50%) scale(.8)}}@keyframes tokkaekkoBg2{0%{opacity:.8;transform:translateY(-50%) scale(1)}to{opacity:1;transform:translateY(-50%) scale(.8)}}.effectWindow .tokkaekko .item.active{-webkit-animation:tokkaekkoActive 3s linear 0s infinite;animation:tokkaekkoActive 3s linear 0s infinite}@-webkit-keyframes tokkaekkoActive{0%{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}to{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}18%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-30px,30px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}37%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-20px,-10px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}60%{-webkit-animation-timing-function:linear;-webkit-transform:translate(30px,20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}82%{-webkit-animation-timing-function:linear;-webkit-transform:translate(20px,-20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}}@keyframes tokkaekkoActive{0%{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}to{-webkit-animation-timing-function:linear;-webkit-transform:translate(0) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}18%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-30px,30px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}37%{-webkit-animation-timing-function:linear;-webkit-transform:translate(-20px,-10px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}60%{-webkit-animation-timing-function:linear;-webkit-transform:translate(30px,20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}82%{-webkit-animation-timing-function:linear;-webkit-transform:translate(20px,-20px) scale(1) rotate(0deg) skew(0deg,0deg);opacity:1}}.effectWindow .tokkaekko .frame01{display:none}.effectWindow .tokkaekko.isShow{background-color:transparent;-webkit-animation:tokkaekkoIsShow .6s linear 0s 1 normal forwards;animation:tokkaekkoIsShow .6s linear 0s 1 normal forwards}@-webkit-keyframes tokkaekkoIsShow{0%{background-color:transparent}to{background-color:rgba(0,0,0,.4)}}@keyframes tokkaekkoIsShow{0%{background-color:transparent}to{background-color:rgba(0,0,0,.4)}}.effectWindow .tokkaekko.isShow .item .charas{-webkit-animation:tokkaekkoIsShowItem .5s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards;animation:tokkaekkoIsShowItem .5s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards}@-webkit-keyframes tokkaekkoIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}@keyframes tokkaekkoIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}.effectWindow .tokkaekko.isHidden{-webkit-animation:tokkaekkoIsHidden .6s linear 0s 1 normal forwards;animation:tokkaekkoIsHidden .6s linear 0s 1 normal forwards}@-webkit-keyframes tokkaekkoIsHidden{0%{background-color:rgba(0,0,0,.4)}to{background-color:transparent}}@keyframes tokkaekkoIsHidden{0%{background-color:rgba(0,0,0,.4)}to{background-color:transparent}}.effectWindow .tokkaekko.isHidden .item .charas{-webkit-animation:tokkaekkoIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards;animation:tokkaekkoIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards}@-webkit-keyframes tokkaekkoIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}@keyframes tokkaekkoIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}.effectWindow .binbo_kawara{width:100%;height:100%;background-color:hsla(0,0%,100%,.8)}.effectWindow .binbo_kawara .item{position:absolute;width:598px;height:339px;top:102px;left:335px;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/binbo_kawara.png)}.effectWindow .binbo_kawara .item:before{content:"";position:absolute;top:calc(50% - 20px);left:calc(50% - 20px);width:20px;height:40px;border-radius:100%;background-color:#fff;box-shadow:0 0 60px 30px #fff,0 0 100px 60px #fff900,0 0 140px 90px #ef0;-webkit-animation:binbo_kawarabefore 1.5s ease 0s infinite alternate;animation:binbo_kawarabefore 1.5s ease 0s infinite alternate}.is-excludeUiAnimation .effectWindow .binbo_kawara .item:before{-webkit-animation:none;animation:none}@-webkit-keyframes binbo_kawarabefore{0%{opacity:0}to{opacity:1}}@keyframes binbo_kawarabefore{0%{opacity:0}to{opacity:1}}.effectWindow .binbo_kawara .item>.img{position:relative;width:100%;height:100%;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/binbo_kawara.png)}.effectWindow .binbo_kawara .frame01{position:absolute;top:0;left:0;width:100%;height:100%;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/binbo_kawara_frame01.png)}.is-excludeDirectingAnimation .effectWindow .binbo_kawara{background-color:hsla(0,0%,100%,.8)!important;-webkit-animation:none;animation:none}.is-excludeDirectingAnimation .effectWindow .binbo_kawara .item{transform:scale(1)!important;-webkit-animation:none;animation:none}.is-excludeDirectingAnimation .effectWindow .binbo_kawara .frame01{opacity:1!important;transform:scale(1)!important;-webkit-animation:none;animation:none}.effectWindow .binbo_kawara.isShow{background-color:hsla(0,0%,100%,0);-webkit-animation:binbo_kawaraIsShow .6s linear 0s 1 normal forwards;animation:binbo_kawaraIsShow .6s linear 0s 1 normal forwards}@-webkit-keyframes binbo_kawaraIsShow{0%{background-color:hsla(0,0%,100%,0)}to{background-color:hsla(0,0%,100%,.8)}}@keyframes binbo_kawaraIsShow{0%{background-color:hsla(0,0%,100%,0)}to{background-color:hsla(0,0%,100%,.8)}}.effectWindow .binbo_kawara.isShow .item{transform:scale(0);-webkit-animation:binbo_kawaraIsShowItem .5s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards;animation:binbo_kawaraIsShowItem .5s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards}@-webkit-keyframes binbo_kawaraIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}@keyframes binbo_kawaraIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}.effectWindow .binbo_kawara.isShow .frame01{opacity:0;-webkit-animation:binbo_kawaraIsShowframe01 .5s cubic-bezier(.33,1,.68,1) .1s 1 normal forwards;animation:binbo_kawaraIsShowframe01 .5s cubic-bezier(.33,1,.68,1) .1s 1 normal forwards}@-webkit-keyframes binbo_kawaraIsShowframe01{0%{opacity:0;transform:scale(1.8)}to{opacity:1;transform:scale(1)}}@keyframes binbo_kawaraIsShowframe01{0%{opacity:0;transform:scale(1.8)}to{opacity:1;transform:scale(1)}}.effectWindow .binbo_kawara.isHidden{-webkit-animation:binbo_kawaraIsHidden .6s linear 0s 1 normal forwards;animation:binbo_kawaraIsHidden .6s linear 0s 1 normal forwards}@-webkit-keyframes binbo_kawaraIsHidden{0%{background-color:hsla(0,0%,100%,.8)}to{background-color:hsla(0,0%,100%,0)}}@keyframes binbo_kawaraIsHidden{0%{background-color:hsla(0,0%,100%,.8)}to{background-color:hsla(0,0%,100%,0)}}.effectWindow .binbo_kawara.isHidden .item{-webkit-animation:binbo_kawaraIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards;animation:binbo_kawaraIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards}@-webkit-keyframes binbo_kawaraIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}@keyframes binbo_kawaraIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}.effectWindow .binbo_kawara.isHidden .item:before{transform-origin:center center;-webkit-animation:binbo_kawaraIsHiddenItemBefore .2s linear 0s 1 normal forwards;animation:binbo_kawaraIsHiddenItemBefore .2s linear 0s 1 normal forwards}@-webkit-keyframes binbo_kawaraIsHiddenItemBefore{0%{transform:scale(1)}to{transform:scale(1.3)}}@keyframes binbo_kawaraIsHiddenItemBefore{0%{transform:scale(1)}to{transform:scale(1.3)}}.effectWindow .binbo_kawara.isHidden .frame01{-webkit-animation:binbo_kawaraIsHiddenframe01 .5s linear 0s 1 normal forwards;animation:binbo_kawaraIsHiddenframe01 .5s linear 0s 1 normal forwards}@-webkit-keyframes binbo_kawaraIsHiddenframe01{0%{opacity:1}to{opacity:0}}@keyframes binbo_kawaraIsHiddenframe01{0%{opacity:1}to{opacity:0}}.effectWindow .onaraman{width:100%;height:100%;background-color:hsla(0,0%,100%,.8)}.effectWindow .onaraman .item{position:absolute;width:245px;height:272px;top:150px;left:0;right:0;margin:auto;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/onaraman.png)}.effectWindow .onaraman .item:before{content:"";position:absolute;top:calc(50% - 20px);left:calc(50% - 20px);width:20px;height:40px;border-radius:100%;background-color:#fff;box-shadow:0 0 60px 30px #fff,0 0 100px 60px #fff900,0 0 140px 90px #ef0;-webkit-animation:onaramanbefore 1.5s ease 0s infinite alternate;animation:onaramanbefore 1.5s ease 0s infinite alternate}.is-excludeUiAnimation .effectWindow .onaraman .item:before{-webkit-animation:none;animation:none}@-webkit-keyframes onaramanbefore{0%{opacity:0}to{opacity:1}}@keyframes onaramanbefore{0%{opacity:0}to{opacity:1}}.effectWindow .onaraman .item>.img{position:relative;width:100%;height:100%;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/onaraman.png)}.effectWindow .onaraman .frame01{position:absolute;top:0;left:0;width:100%;height:100%;background-image:url(https://momotetsu-edu.konami.net/lite/assets/images/ui/global/effect-window/onaraman_frame01.png)}.is-excludeDirectingAnimation .effectWindow .onaraman{background-color:hsla(0,0%,100%,.8)!important;-webkit-animation:none;animation:none}.is-excludeDirectingAnimation .effectWindow .onaraman .frame01,.is-excludeDirectingAnimation .effectWindow .onaraman .item{transform:scale(1)!important;-webkit-animation:none;animation:none}.is-excludeDirectingAnimation .effectWindow .onaraman .frame01{opacity:1!important}.effectWindow .onaraman.isShow{background-color:hsla(0,0%,100%,0);-webkit-animation:onaramanIsShow .6s linear 0s 1 normal forwards;animation:onaramanIsShow .6s linear 0s 1 normal forwards}@-webkit-keyframes onaramanIsShow{0%{background-color:hsla(0,0%,100%,0)}to{background-color:hsla(0,0%,100%,.8)}}@keyframes onaramanIsShow{0%{background-color:hsla(0,0%,100%,0)}to{background-color:hsla(0,0%,100%,.8)}}.effectWindow .onaraman.isShow .item{transform:scale(0);-webkit-animation:onaramanIsShowItem .5s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards;animation:onaramanIsShowItem .5s cubic-bezier(.34,1.56,.64,1) 0s 1 normal forwards}@-webkit-keyframes onaramanIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}@keyframes onaramanIsShowItem{0%{transform:scale(0)}to{transform:scale(1)}}.effectWindow .onaraman.isShow .frame01{opacity:0;-webkit-animation:onaramanIsShowframe01 .5s cubic-bezier(.33,1,.68,1) .1s 1 normal forwards;animation:onaramanIsShowframe01 .5s cubic-bezier(.33,1,.68,1) .1s 1 normal forwards}@-webkit-keyframes onaramanIsShowframe01{0%{opacity:0;transform:scale(1.8)}to{opacity:1;transform:scale(1)}}@keyframes onaramanIsShowframe01{0%{opacity:0;transform:scale(1.8)}to{opacity:1;transform:scale(1)}}.effectWindow .onaraman.isHidden{-webkit-animation:onaramanIsHidden .6s linear 0s 1 normal forwards;animation:onaramanIsHidden .6s linear 0s 1 normal forwards}@-webkit-keyframes onaramanIsHidden{0%{background-color:hsla(0,0%,100%,.8)}to{background-color:hsla(0,0%,100%,0)}}@keyframes onaramanIsHidden{0%{background-color:hsla(0,0%,100%,.8)}to{background-color:hsla(0,0%,100%,0)}}.effectWindow .onaraman.isHidden .item{-webkit-animation:onaramanIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards;animation:onaramanIsHiddenItem .4s cubic-bezier(.36,0,.66,-.56) .2s 1 normal forwards}@-webkit-keyframes onaramanIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}@keyframes onaramanIsHiddenItem{0%{transform:scale(1)}to{transform:scale(0)}}.effectWindow .onaraman.isHidden .item:before{transform-origin:center center;-webkit-animation:onaramanIsHiddenItemBefore .2s linear 0s 1 normal forwards;animation:onaramanIsHiddenItemBefore .2s linear 0s 1 normal forwards}@-webkit-keyframes onaramanIsHiddenItemBefore{0%{transform:scale(1)}to{transform:scale(1.3)}}@keyframes onaramanIsHiddenItemBefore{0%{transform:scale(1)}to{transform:scale(1.3)}}.effectWindow .onaraman.isHidden .frame01{-webkit-animation:onaramanIsHiddenframe01 .5s linear 0s 1 normal forwards;animation:onaramanIsHiddenframe01 .5s linear 0s 1 normal forwards}@-webkit-keyframes onaramanIsHiddenframe01{0%{opacity:1}to{opacity:0}}@keyframes onaramanIsHiddenframe01{0%{opacity:1}to{opacity:0}}', ""]),
        a.exports = e
    },
    557: function(a, i, t) {
        "use strict";
        t.r(i);
        var e = t(6)
          , n = t(4)
          , o = (t(21),
        t(29),
        t(57),
        t(44),
        t(39),
        t(69),
        t(30),
        t(70),
        t(17))
          , s = t(54)
          , r = t(143);
        function m(a, i) {
            var t = Object.keys(a);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(a);
                i && (e = e.filter((function(i) {
                    return Object.getOwnPropertyDescriptor(a, i).enumerable
                }
                ))),
                t.push.apply(t, e)
            }
            return t
        }
        function c(a) {
            for (var i = 1; i < arguments.length; i++) {
                var t = null != arguments[i] ? arguments[i] : {};
                i % 2 ? m(Object(t), !0).forEach((function(i) {
                    Object(e.a)(a, i, t[i])
                }
                )) : Object.getOwnPropertyDescriptors ? Object.defineProperties(a, Object.getOwnPropertyDescriptors(t)) : m(Object(t)).forEach((function(i) {
                    Object.defineProperty(a, i, Object.getOwnPropertyDescriptor(t, i))
                }
                ))
            }
            return a
        }
        var k = Object(o.b)({
            extends: s.a
        });
        function f(a, i) {
            var t = Object.keys(a);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(a);
                i && (e = e.filter((function(i) {
                    return Object.getOwnPropertyDescriptor(a, i).enumerable
                }
                ))),
                t.push.apply(t, e)
            }
            return t
        }
        function l(a) {
            for (var i = 1; i < arguments.length; i++) {
                var t = null != arguments[i] ? arguments[i] : {};
                i % 2 ? f(Object(t), !0).forEach((function(i) {
                    Object(e.a)(a, i, t[i])
                }
                )) : Object.getOwnPropertyDescriptors ? Object.defineProperties(a, Object.getOwnPropertyDescriptors(t)) : f(Object(t)).forEach((function(i) {
                    Object.defineProperty(a, i, Object.getOwnPropertyDescriptor(t, i))
                }
                ))
            }
            return a
        }
        var p = Object(o.b)({
            name: "EffectWindow",
            extends: k,
            setup: function(a, i) {
                var t = function(a) {
                    var i = Object(s.b)(a)
                      , t = new r.a;
                    return c(c({}, i), {}, {
                        show: function(a) {
                            return t = new r.a,
                            i._start(this, a),
                            t.promise
                        },
                        hide: function() {
                            return t = new r.a,
                            this.hideStart(),
                            t.promise
                        },
                        showComplete: function() {
                            t.resolve()
                        },
                        hideComplete: function() {
                            i.complete(),
                            t.resolve()
                        }
                    })
                }(i)
                  , e = Object(o.k)("")
                  , m = Object(o.k)(!1)
                  , k = Object(o.k)(!1)
                  , f = Object(o.k)("");
                function p() {
                    return (p = Object(n.a)(regeneratorRuntime.mark((function a(i) {
                        return regeneratorRuntime.wrap((function(a) {
                            for (; ; )
                                switch (a.prev = a.next) {
                                case 0:
                                    return e.value = i.type,
                                    a.next = 3,
                                    g();
                                case 3:
                                    t.showComplete();
                                case 4:
                                case "end":
                                    return a.stop()
                                }
                        }
                        ), a)
                    }
                    )))).apply(this, arguments)
                }
                function d() {
                    return (d = Object(n.a)(regeneratorRuntime.mark((function a() {
                        return regeneratorRuntime.wrap((function(a) {
                            for (; ; )
                                switch (a.prev = a.next) {
                                case 0:
                                    return a.next = 2,
                                    b();
                                case 2:
                                    w();
                                case 3:
                                case "end":
                                    return a.stop()
                                }
                        }
                        ), a)
                    }
                    )))).apply(this, arguments)
                }
                function w() {
                    k.value = !1,
                    m.value = !1,
                    e.value = "",
                    t.hideComplete()
                }
                function g() {
                    return t.CONFIG.DIRECTING_ANIMATION ? new Promise((function(a, i) {
                        f.value.addEventListener("animationend", (function i(t) {
                            t.animationName === "".concat(e.value, "IsShow") && (f.value.removeEventListener("animationend", i),
                            k.value = !1,
                            a())
                        }
                        )),
                        k.value = !0
                    }
                    )) : (k.value = !1,
                    Promise.resolve())
                }
                function b() {
                    return t.CONFIG.DIRECTING_ANIMATION ? new Promise((function(a, i) {
                        f.value.addEventListener("animationend", (function i(t) {
                            t.animationName === "".concat(e.value, "IsHidden") && (f.value.removeEventListener("animationend", i),
                            m.value = !1,
                            a())
                        }
                        )),
                        m.value = !0
                    }
                    )) : (m.value = !1,
                    Promise.resolve())
                }
                return l(l({}, t), {}, {
                    started: function(a) {
                        return p.apply(this, arguments)
                    },
                    hideStart: function() {
                        return d.apply(this, arguments)
                    },
                    imgName: e,
                    isHidden: m,
                    isShow: k,
                    ImgWrap: f
                })
            }
        })
          , d = p
          , w = (t(1057),
        t(82))
          , g = Object(w.a)(d, (function() {
            var a = this
              , i = a.$createElement
              , t = a._self._c || i;
            return t("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: a.isVisible,
                    expression: "isVisible"
                }],
                staticClass: "effectWindow"
            }, [t("div", {
                ref: "ImgWrap",
                class: [a.imgName, {
                    isHidden: a.isHidden
                }, {
                    isShow: a.isShow
                }]
            }, [t("div", {
                staticClass: "item",
                class: {
                    active: !a.isHidden && !a.isShow
                }
            }, [t("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "kinensennin" == a.imgName || "cardnokamisama" == a.imgName || "binbo_kawara" == a.imgName || "onaraman" == a.imgName,
                    expression: "\n          imgName == 'kinensennin' ||\n          imgName == 'cardnokamisama' ||\n          imgName == 'binbo_kawara' ||\n          imgName == 'onaraman'\n        "
                }],
                staticClass: "img"
            }), a._v(" "), t("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "toranitsubasa" == a.imgName,
                    expression: "imgName == 'toranitsubasa'"
                }],
                staticClass: "img"
            }, [t("div", {
                staticClass: "tigers"
            }, a._l(5, (function(i) {
                return t("div", {
                    key: "tiger1_" + i,
                    class: "tiger tiger" + i
                }, [t("div", [t("img", {
                    attrs: {
                        src: a.getStaticAssetsPath("/images/ui/global/effect-window/toranitsubasa.png"),
                        alt: ""
                    }
                })]), a._v(" "), a._l(4, (function(i) {
                    return t("div", {
                        key: "star1_" + i,
                        class: "star star" + i
                    }, [t("img", {
                        attrs: {
                            src: a.getStaticAssetsPath("/images/ui/global/effect-window/toranitsubasa_star.png"),
                            alt: ""
                        }
                    })])
                }
                ))], 2)
            }
            )), 0)]), a._v(" "), t("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "saikai" == a.imgName,
                    expression: "imgName == 'saikai'"
                }],
                staticClass: "img"
            }, [t("div", {
                staticClass: "lights"
            }, [t("img", {
                attrs: {
                    src: a.getStaticAssetsPath("/images/ui/global/effect-window/saikai_lights.png"),
                    alt: ""
                }
            })]), a._v(" "), t("div", {
                staticClass: "stars"
            }, [a._l(20, (function(i) {
                return t("div", {
                    key: "star2_" + i,
                    staticClass: "star"
                }, [t("img", {
                    attrs: {
                        src: a.getStaticAssetsPath("/images/ui/global/effect-window/saikai_star.png"),
                        alt: ""
                    }
                })])
            }
            )), a._v(" "), a._l(10, (function(i) {
                return t("div", {
                    key: "star3_" + i,
                    staticClass: "star"
                }, [t("img", {
                    attrs: {
                        src: a.getStaticAssetsPath("/images/ui/global/effect-window/saikai_star2.png"),
                        alt: ""
                    }
                })])
            }
            ))], 2), a._v(" "), t("div", {
                staticClass: "megami"
            }, [t("img", {
                attrs: {
                    src: a.getStaticAssetsPath("/images/ui/global/effect-window/saikai.png"),
                    alt: ""
                }
            })])]), a._v(" "), t("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "tokkaekko" == a.imgName,
                    expression: "imgName == 'tokkaekko'"
                }],
                staticClass: "img"
            }, [t("div", {
                staticClass: "charas chara-r-1"
            }, [t("div", {
                staticClass: "bg"
            }, [t("img", {
                attrs: {
                    src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_r_bg.png"),
                    alt: ""
                }
            })]), a._v(" "), t("div", {
                staticClass: "chara"
            }, [t("img", {
                attrs: {
                    src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_r.png"),
                    alt: ""
                }
            })]), a._v(" "), a._l(4, (function(i) {
                return t("div", {
                    key: "gitter1_" + i,
                    class: "gitter gitter" + i
                }, [t("img", {
                    attrs: {
                        src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_r_gitter.png"),
                        alt: ""
                    }
                })])
            }
            ))], 2), a._v(" "), t("div", {
                staticClass: "charas chara-r-2"
            }, [t("div", {
                staticClass: "bg"
            }, [t("img", {
                attrs: {
                    src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_r_bg.png"),
                    alt: ""
                }
            })]), a._v(" "), t("div", {
                staticClass: "chara"
            }, [t("img", {
                attrs: {
                    src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_r.png"),
                    alt: ""
                }
            })]), a._v(" "), a._l(4, (function(i) {
                return t("div", {
                    key: "gitter2_" + i,
                    class: "gitter gitter" + i
                }, [t("img", {
                    attrs: {
                        src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_r_gitter.png"),
                        alt: ""
                    }
                })])
            }
            ))], 2), a._v(" "), t("div", {
                staticClass: "charas chara-l-1"
            }, [t("div", {
                staticClass: "bg"
            }, [t("img", {
                attrs: {
                    src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_l_bg.png"),
                    alt: ""
                }
            })]), a._v(" "), t("div", {
                staticClass: "chara"
            }, [t("img", {
                attrs: {
                    src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_l.png"),
                    alt: ""
                }
            })]), a._v(" "), a._l(2, (function(i) {
                return t("div", {
                    key: "gitter3_" + i,
                    class: "gitter gitter" + i
                }, [t("img", {
                    attrs: {
                        src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_l_gitter.png"),
                        alt: ""
                    }
                })])
            }
            ))], 2), a._v(" "), t("div", {
                staticClass: "charas chara-l-2"
            }, [t("div", {
                staticClass: "bg"
            }, [t("img", {
                attrs: {
                    src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_l_bg.png"),
                    alt: ""
                }
            })]), a._v(" "), t("div", {
                staticClass: "chara"
            }, [t("img", {
                attrs: {
                    src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_l.png"),
                    alt: ""
                }
            })]), a._v(" "), a._l(2, (function(i) {
                return t("div", {
                    key: "gitter4_" + i,
                    class: "gitter gitter" + i
                }, [t("img", {
                    attrs: {
                        src: a.getStaticAssetsPath("/images/ui/global/effect-window/tokkaekko_l_gitter.png"),
                        alt: ""
                    }
                })])
            }
            ))], 2)])]), a._v(" "), t("div", {
                staticClass: "frame01"
            })])])
        }
        ), [], !1, null, null, null);
        i.default = g.exports
    }
}]);

(this.webpackJsonp = this.webpackJsonp || []).push([[0], { //
    1032: function(e, t, n) {
        var a = n(1050);
        a.__esModule && (a = a.default),
        "string" == typeof a && (a = [[e.i, a, ""]]),
        a.locals && (e.exports = a.locals);
        (0,
        n(110).default)("cf7bf328", a, !1, {
            sourceMap: !1
        })
    },
    1049: function(e, t, n) {
        "use strict";
        n(1032)
    },
    1050: function(e, t, n) {
        var a = n(109)(!1);
        a.push([e.i, ".u-ta-left[data-v-45b55882]{text-align:left!important}.u-ta-right[data-v-45b55882]{text-align:right!important}.u-ta-center[data-v-45b55882]{text-align:center!important}.u-pointer-events-none[data-v-45b55882]{pointer-events:none!important}.CommandAsync[data-v-45b55882]{position:relative;width:100%;padding:0 0 0 55px}.CommandAsync>.inner[data-v-45b55882]{background-color:rgba(252,248,232,.9);padding:5px 6px;box-shadow:0 4px 0 0 #826d59;border-radius:7px;border:4px solid #ae9371}.CommandAsync>.inner.showSubInfo .label[data-v-45b55882]{display:inline-block;width:55%}.CommandAsync>.inner.showSubInfo .subInfo[data-v-45b55882]{display:inline-block;width:41%}.CommandAsync button[data-v-45b55882]{position:relative;width:100%;text-align:left;font-size:46.67px;line-height:1;padding:3px 7px;color:#513e3b}.is-ruby .CommandAsync button[data-v-45b55882]{font-size:40px}.CommandAsync button.color_red[data-v-45b55882]{color:#af2d23}.CommandAsync button.focus[data-v-45b55882]{background-color:#ffa72d}.CommandAsync button.focus.active[data-v-45b55882]{-webkit-animation:command_focus-data-v-45b55882 .55s cubic-bezier(.45,0,.55,1) infinite alternate;animation:command_focus-data-v-45b55882 .55s cubic-bezier(.45,0,.55,1) infinite alternate}.CommandAsync button.focus.active .focusIcon[data-v-45b55882]{display:block}.is-excludeUiAnimation .CommandAsync button.focus.active[data-v-45b55882]{-webkit-animation:none;animation:none}.CommandAsync button .focusIcon[data-v-45b55882]{display:none;position:absolute;top:-4px;left:-66px;width:73px;-webkit-animation:command_focus_icon-data-v-45b55882 .55s cubic-bezier(.45,0,.55,1) infinite alternate;animation:command_focus_icon-data-v-45b55882 .55s cubic-bezier(.45,0,.55,1) infinite alternate}.is-excludeUiAnimation .CommandAsync button .focusIcon[data-v-45b55882]{-webkit-animation:none;animation:none}@-webkit-keyframes command_focus-data-v-45b55882{0%{background-color:#ffa72d}to{background-color:rgba(255,167,45,.6)}}@keyframes command_focus-data-v-45b55882{0%{background-color:#ffa72d}to{background-color:rgba(255,167,45,.6)}}@-webkit-keyframes command_focus_icon-data-v-45b55882{0%{transform:translateY(-5%)}to{transform:translateY(3%)}}@keyframes command_focus_icon-data-v-45b55882{0%{transform:translateY(-5%)}to{transform:translateY(3%)}}", ""]),
        e.exports = a
    },
    540: function(e, t, n) {
        "use strict";
        n.r(t);
        n(57),
        n(44),
        n(39),
        n(69),
        n(30),
        n(70);
        var a = n(4)
          , r = n(6)
          , o = (n(21),
        n(55),
        n(29),
        n(17))
          , c = n(54);
        function i(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                t && (a = a.filter((function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }
                ))),
                n.push.apply(n, a)
            }
            return n
        }
        function u(e) {
            return function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(n), !0).forEach((function(t) {
                        Object(r.a)(e, t, n[t])
                    }
                    )) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    }
                    ))
                }
                return e
            }({}, Object(c.b)(e))
        }
        var s = Object(o.b)({
            extends: c.a
        })
          , l = n(0)
          , f = n(24)
          , m = n(5)
          , b = n(247);
        function d(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(e);
                t && (a = a.filter((function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }
                ))),
                n.push.apply(n, a)
            }
            return n
        }
        function v(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? d(Object(n), !0).forEach((function(t) {
                    Object(r.a)(e, t, n[t])
                }
                )) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : d(Object(n)).forEach((function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                }
                ))
            }
            return e
        }
        var p = Object(o.b)({
            name: "CommandAsync",
            extends: s,
            emits: {
                decide: function(e) {
                    return !0
                },
                focused: function(e) {
                    return !0
                },
                focusedIdx: function(e) {
                    return !0
                }
            },
            setup: function(e, t) {
                var n = u(t)
                  , r = Object(o.k)([])
                  , c = Object(o.k)(!0)
                  , i = Object(o.k)(0)
                  , s = 0
                  , d = 0
                  , p = Object(o.k)([])
                  , y = Object(o.k)([])
                  , h = !1
                  , g = Object(o.a)((function() {
                    return r.value.map((function(e) {
                        return v(v({}, e), {}, {
                            color: e.active ? "nomal" : "red"
                        })
                    }
                    ))
                }
                ));
                function O(e) {
                    return x.apply(this, arguments)
                }
                function x() {
                    return (x = Object(a.a)(regeneratorRuntime.mark((function e(t) {
                        return regeneratorRuntime.wrap((function(e) {
                            for (; ; )
                                switch (e.prev = e.next) {
                                case 0:
                                    if (w(t.labels),
                                    C(t.active),
                                    !t.focusLabel) {
                                        e.next = 5;
                                        break
                                    }
                                    return e.next = 5,
                                    S(Y(t.focusLabel));
                                case 5:
                                    if (!t.focusIndex) {
                                        e.next = 8;
                                        break
                                    }
                                    return e.next = 8,
                                    S(t.focusIndex);
                                case 8:
                                    i.value = s,
                                    d = i.value,
                                    E();
                                case 11:
                                case "end":
                                    return e.stop()
                                }
                        }
                        ), e)
                    }
                    )))).apply(this, arguments)
                }
                function w(e) {
                    return _.apply(this, arguments)
                }
                function _() {
                    return (_ = Object(a.a)(regeneratorRuntime.mark((function e(t) {
                        return regeneratorRuntime.wrap((function(e) {
                            for (; ; )
                                switch (e.prev = e.next) {
                                case 0:
                                    return r.value = t,
                                    y.value = r.value.map((function(e) {
                                        return e.label
                                    }
                                    )),
                                    e.next = 4,
                                    S();
                                case 4:
                                    E();
                                case 5:
                                case "end":
                                    return e.stop()
                                }
                        }
                        ), e)
                    }
                    )))).apply(this, arguments)
                }
                function S(e) {
                    return new Promise((function(t, n) {
                        e && (s = e),
                        (s < 0 || s > r.value.length - 1) && (s = 0),
                        t()
                    }
                    ))
                }
                function C(e) {
                    c.value = e,
                    z(),
                    e && t.emit("focused", r.value[i.value].label)
                }
                function E(e) {
                    (e || 0 === e) && (i.value = e),
                    i.value < 0 ? i.value = 0 : i.value >= r.value.length - 1 && (i.value = r.value.length - 1),
                    d !== i.value && t.emit("focused", r.value[i.value].label),
                    d !== i.value && t.emit("focusedIdx", i.value),
                    d = i.value
                }
                var j = {
                    isCancel: !1,
                    toActiveValue: !0,
                    isCancelLastFocus: !1
                };
                function k() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : j;
                    return new Promise((function(t, n) {
                        C(!0),
                        l.r.updateAuthType(f.a.ASYNC_COMMAND);
                        var a = function() {
                            if (r.value[i.value].active) {
                                var e = r.value[i.value].label
                                  , t = e === b.j || e === b.k ? "MT30_SE_SYS_CANCEL" : "MT30_SE_SYS_DECIDE";
                                l.z.playSE(t),
                                c(r.value[i.value].label)
                            } else
                                l.z.playSE("MT30_SE_SYS_FAILURE")
                        }
                          , o = function() {
                            l.z.playSE("MT30_SE_SYS_CANCEL"),
                            c("cancel")
                        }
                          , c = function(n) {
                            l.r.emitter.off("decide:asyncCommand", a),
                            l.r.emitter.off("moveUp:asyncCommand", R),
                            l.r.emitter.off("moveDown:asyncCommand", L),
                            e.isCancel && l.r.emitter.off("cancel:asyncCommand", o),
                            e.isCancelLastFocus && l.r.emitter.off("cancel:asyncCommand", M),
                            C(e.toActiveValue),
                            l.r.updateAuthType(f.a.DEFAULT),
                            t({
                                label: n,
                                index: i.value
                            })
                        };
                        l.r.emitter.on("decide:asyncCommand", a),
                        l.r.emitter.on("moveUp:asyncCommand", R),
                        l.r.emitter.on("moveDown:asyncCommand", L),
                        e.isCancel && l.r.emitter.on("cancel:asyncCommand", o),
                        e.isCancelLastFocus && l.r.emitter.on("cancel:asyncCommand", M)
                    }
                    ))
                }
                function A() {
                    return A = Object(a.a)(regeneratorRuntime.mark((function e() {
                        var t, n, a = arguments;
                        return regeneratorRuntime.wrap((function(e) {
                            for (; ; )
                                switch (e.prev = e.next) {
                                case 0:
                                    return t = a.length > 0 && void 0 !== a[0] ? a[0] : j,
                                    e.next = 3,
                                    k(t);
                                case 3:
                                    return n = e.sent,
                                    e.abrupt("return", n.label);
                                case 5:
                                case "end":
                                    return e.stop()
                                }
                        }
                        ), e)
                    }
                    ))),
                    A.apply(this, arguments)
                }
                function I() {
                    return I = Object(a.a)(regeneratorRuntime.mark((function e() {
                        var t, n, a = arguments;
                        return regeneratorRuntime.wrap((function(e) {
                            for (; ; )
                                switch (e.prev = e.next) {
                                case 0:
                                    return t = a.length > 0 && void 0 !== a[0] ? a[0] : j,
                                    e.next = 3,
                                    k(t);
                                case 3:
                                    return n = e.sent,
                                    e.abrupt("return", n);
                                case 5:
                                case "end":
                                    return e.stop()
                                }
                        }
                        ), e)
                    }
                    ))),
                    I.apply(this, arguments)
                }
                var D = !1;
                function T() {
                    if (!c)
                        return !1;
                    var e = r.value[i.value].active ? "MT30_SE_SYS_DECIDE" : "MT30_SE_SYS_FAILURE";
                    l.z.playSE(e),
                    t.emit("decide", r.value[i.value].label)
                }
                function P() {
                    if (!c)
                        return !1;
                    h || l.z.playSE("MT30_SE_SYS_CANCEL"),
                    t.emit("decide", "cancel")
                }
                function R() {
                    if (!c)
                        return !1;
                    l.z.playSE("MT30_SE_SYS_CURSOR"),
                    i.value--,
                    i.value < 0 && (i.value = r.value.length - 1),
                    E()
                }
                function L() {
                    if (!c)
                        return !1;
                    l.z.playSE("MT30_SE_SYS_CURSOR"),
                    i.value++,
                    i.value > r.value.length - 1 && (i.value = 0),
                    E()
                }
                function M() {
                    l.z.playSE("MT30_SE_SYS_CURSOR"),
                    i.value = r.value.length - 1,
                    E()
                }
                function Y(e) {
                    var t = y.value.indexOf(e);
                    return t > -1 ? t : 0
                }
                function z() {
                    c.value && n.isVisible.value ? function() {
                        if (D)
                            return !1;
                        D = !0,
                        l.r.emitter.on("moveUp", R),
                        l.r.emitter.on("moveDown", L),
                        l.r.emitter.on("decide", T),
                        l.r.emitter.on("cancel", P)
                    }() : function() {
                        if (!D)
                            return !1;
                        D = !1,
                        l.r.emitter.off("moveUp", R),
                        l.r.emitter.off("moveDown", L),
                        l.r.emitter.off("decide", T),
                        l.r.emitter.off("cancel", P)
                    }()
                }
                var U = !1;
                function N() {
                    return (N = Object(a.a)(regeneratorRuntime.mark((function e(t, a) {
                        return regeneratorRuntime.wrap((function(e) {
                            for (; ; )
                                switch (e.prev = e.next) {
                                case 0:
                                    if (!n.isExcludeTouchEvent(t) && !U && i.value === a && c.value) {
                                        e.next = 2;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 2:
                                    return U = !0,
                                    l.r.serveTouchAction(l.k.DECIDE),
                                    e.next = 6,
                                    Object(m.N)(200);
                                case 6:
                                    U = !1;
                                case 7:
                                case "end":
                                    return e.stop()
                                }
                        }
                        ), e)
                    }
                    )))).apply(this, arguments)
                }
                function F() {
                    return (F = Object(a.a)(regeneratorRuntime.mark((function e(t, a) {
                        return regeneratorRuntime.wrap((function(e) {
                            for (; ; )
                                switch (e.prev = e.next) {
                                case 0:
                                    if (!n.isExcludeTouchEvent(t) && !U && c.value) {
                                        e.next = 2;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 2:
                                    U = !0,
                                    i.value = a,
                                    E(),
                                    U = !1;
                                case 6:
                                case "end":
                                    return e.stop()
                                }
                        }
                        ), e)
                    }
                    )))).apply(this, arguments)
                }
                return v(v({}, n), {}, {
                    labels: r,
                    active: c,
                    activeIndex: i,
                    subInfos: p,
                    forDisplayLabels: g,
                    started: function(e) {
                        e ? O(e) : (i.value = s,
                        d = i.value,
                        E()),
                        z()
                    },
                    setParams: O,
                    setLabels: w,
                    setActive: C,
                    setFocusLabel: function(e) {
                        E(Y(e))
                    },
                    setFocusIndex: E,
                    setSubInfos: function(e) {
                        p.value = e
                    },
                    complete: function() {
                        n.complete(),
                        z()
                    },
                    asyncActionDecide: function() {
                        return A.apply(this, arguments)
                    },
                    asyncActionDecide2: function() {
                        return I.apply(this, arguments)
                    },
                    focusLast: M,
                    onMoveUp: R,
                    onMoveDown: L,
                    muteCancel: function(e) {
                        h = e
                    },
                    onTouchEnd: function(e, t) {
                        return N.apply(this, arguments)
                    },
                    onTouchStart: function(e, t) {
                        return F.apply(this, arguments)
                    }
                })
            }
        })
          , y = p
          , h = (n(1049),
        n(82))
          , g = Object(h.a)(y, (function() {
            var e = this
              , t = e.$createElement
              , n = e._self._c || t;
            return n("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.isVisible,
                    expression: "isVisible"
                }],
                staticClass: "CommandAsync",
                class: {
                    "u-pointer-events-none": !e.active
                }
            }, [n("div", {
                staticClass: "inner",
                class: [{
                    showSubInfo: e.labels.length === e.subInfos.length
                }]
            }, e._l(e.forDisplayLabels, (function(t, a) {
                return n("button", {
                    directives: [{
                        name: "lasttouchend",
                        rawName: "v-lasttouchend:[index]",
                        value: e.onTouchEnd,
                        expression: "onTouchEnd",
                        arg: a
                    }],
                    key: "command_" + t.label + "-" + a,
                    staticClass: "pointerEventsAuto",
                    class: [{
                        focus: a === e.activeIndex
                    }, {
                        active: e.active
                    }, "color_" + t.color],
                    on: {
                        touchstart: function(t) {
                            return e.onTouchStart(t, a)
                        }
                    }
                }, [n("div", {
                    staticClass: "focusIcon"
                }, [n("img", {
                    attrs: {
                        src: e.getStaticAssetsPath("/images/ui/loading/momo.png"),
                        alt: ""
                    }
                })]), e._v(" "), n("p", {
                    staticClass: "label",
                    domProps: {
                        innerHTML: e._s(t.label)
                    }
                }), e._v(" "), n("p", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: e.labels.length === e.subInfos.length,
                        expression: "labels.length === subInfos.length"
                    }],
                    staticClass: "subInfo",
                    domProps: {
                        innerHTML: e._s(e.subInfos[a])
                    }
                })])
            }
            )), 0)])
        }
        ), [], !1, null, "45b55882", null);
        t.default = g.exports
    }
}]);
